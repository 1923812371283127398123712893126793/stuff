const credits = `
Credits:
- Sempiller
- Hatchinng
- Chris

>>> Special thanks to Snek aka Mr. Bumpkin
`;

console.log(credits);